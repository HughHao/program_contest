# _*_ coding:utf-8 _*_
# 开发人员：郝海强
# 开发时间：2020/4/316:17
# 文件名称：main2.py.py
# 开发工具：PyCharm

import time
time_start = time.time()
#from johnson import *
file_path = 'data/test_data4.txt'
start_p=[]
end_p=[]
with open (file_path) as file_object:
    for line in file_object:
        #line = lines.readlines()
        li = line.split(",")
        start_p.append(int(li[0]))
        end_p.append(int(li[1]))
# print(int(line.rstrip()))
# total = start_p+end_p
# total = list(set(total))
#total.sort()
graph = {}
keys=[]
for index in range(len(start_p)):
    key = start_p[index]
    value = end_p[index]
    if key not in keys:
        graph[key] = [value]
        keys.append(key)
    else:
        graph[key].append(value)
# cycle = list(tuple(simple_cycles(graph)))
# print(len(cycle))
# print(cycle)
for k,v in graph.items():
    print(k,':',v)

time_end = time.time()
time_c = time_end - time_start
print('time_cost',time_c,'s')