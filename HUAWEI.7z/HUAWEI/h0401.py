import networkx as nx
import matplotlib.pyplot as plt
D=nx.read_edgelist('test_data3.txt','rb',create_using=nx.DiGraph())
a=list(nx.simple_cycles(D))
